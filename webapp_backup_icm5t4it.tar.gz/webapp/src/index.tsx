import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { renderer } from './renderer'
import { SatelliteImageProcessor } from './image-processing'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// JSX renderer middleware
app.use(renderer)

// API Routes for Image Processing
app.post('/api/upload', async (c) => {
  try {
    const formData = await c.req.formData()
    const file = formData.get('image') as File
    
    if (!file) {
      return c.json({ error: 'No image file provided' }, 400)
    }

    // Convert file to base64 for processing
    const arrayBuffer = await file.arrayBuffer()
    const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)))
    
    return c.json({
      success: true,
      filename: file.name,
      size: file.size,
      type: file.type,
      data: `data:${file.type};base64,${base64}`
    })
  } catch (error) {
    return c.json({ error: 'Failed to process image upload' }, 500)
  }
})

app.post('/api/dehaze', async (c) => {
  try {
    const { imageData, algorithm, parameters } = await c.req.json()
    const startTime = Date.now()
    
    // Convert base64 to ImageData
    const inputImage = await SatelliteImageProcessor.base64ToImageData(imageData)
    
    let processedImage;
    
    // Apply selected algorithm
    switch (algorithm) {
      case 'dark-channel-prior':
        processedImage = SatelliteImageProcessor.darkChannelPrior(inputImage, parameters)
        break
      case 'atmospheric-scattering':
        processedImage = SatelliteImageProcessor.atmosphericScattering(inputImage, parameters)
        break
      case 'multispectral-enhancement':
        processedImage = SatelliteImageProcessor.multispectralEnhancement(inputImage, parameters)
        break
      default:
        throw new Error(`Unknown algorithm: ${algorithm}`)
    }
    
    // Convert back to base64
    const processedBase64 = SatelliteImageProcessor.imageDataToBase64(processedImage)
    const processingTime = Date.now() - startTime
    
    return c.json({
      success: true,
      processedImage: processedBase64,
      algorithm,
      parameters,
      processingTime,
      metadata: {
        originalSize: `${inputImage.width}x${inputImage.height}`,
        processedSize: `${processedImage.width}x${processedImage.height}`,
        algorithmDetails: getAlgorithmDetails(algorithm)
      }
    })
  } catch (error) {
    console.error('Dehazing error:', error)
    return c.json({ error: `Failed to process dehazing: ${error.message}` }, 500)
  }
})

app.get('/api/algorithms', (c) => {
  return c.json({
    algorithms: [
      {
        id: 'dark-channel-prior',
        name: 'Dark Channel Prior',
        description: 'Based on the observation that most local patches in haze-free outdoor images contain some pixels with very low intensities in at least one color channel',
        parameters: [
          { name: 'omega', type: 'number', min: 0.1, max: 1.0, default: 0.95, description: 'Haze removal ratio' },
          { name: 't0', type: 'number', min: 0.05, max: 0.3, default: 0.1, description: 'Minimum transmission' },
          { name: 'radius', type: 'number', min: 3, max: 15, default: 7, description: 'Filter radius' }
        ]
      },
      {
        id: 'atmospheric-scattering',
        name: 'Atmospheric Scattering Model',
        description: 'Models the atmospheric scattering effects in satellite imagery',
        parameters: [
          { name: 'beta', type: 'number', min: 0.1, max: 2.0, default: 1.0, description: 'Scattering coefficient' },
          { name: 'airlight', type: 'number', min: 0.5, max: 1.0, default: 0.8, description: 'Global atmospheric light' }
        ]
      },
      {
        id: 'multispectral-enhancement',
        name: 'Multispectral Enhancement',
        description: 'Utilizes information from multiple spectral bands for enhanced dehazing',
        parameters: [
          { name: 'bands', type: 'array', default: ['red', 'green', 'blue', 'nir'], description: 'Selected spectral bands' },
          { name: 'weight_nir', type: 'number', min: 0.0, max: 2.0, default: 1.2, description: 'NIR band weight' }
        ]
      }
    ]
  })
})

// Main application page
app.get('/', (c) => {
  return c.render(
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            <i className="fas fa-satellite mr-3 text-blue-600"></i>
            Multispectral Satellite Image Dehazing
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Advanced atmospheric haze removal for satellite imagery using state-of-the-art algorithms
            including Dark Channel Prior, Atmospheric Scattering Models, and Multispectral Enhancement techniques.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">
              <i className="fas fa-upload mr-2 text-green-600"></i>
              Upload Satellite Image
            </h2>
            
            <div id="upload-area" className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors cursor-pointer">
              <i className="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
              <p className="text-gray-600">Click to upload or drag and drop your satellite image</p>
              <p className="text-sm text-gray-500 mt-2">Supports: JPEG, PNG, TIFF (Max 10MB)</p>
              <input type="file" id="image-input" accept="image/*" className="hidden" />
            </div>

            <div id="image-preview" className="mt-4 hidden">
              <h3 className="font-medium text-gray-700 mb-2">Original Image:</h3>
              <img id="original-image" className="w-full h-64 object-cover rounded border" alt="Original" />
              <div className="mt-2 text-sm text-gray-600">
                <span id="image-info"></span>
              </div>
            </div>
          </div>

          {/* Algorithm Selection */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">
              <i className="fas fa-cogs mr-2 text-purple-600"></i>
              Dehazing Algorithm
            </h2>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Algorithm:</label>
              <select id="algorithm-select" className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="">Choose an algorithm...</option>
              </select>
            </div>

            <div id="algorithm-description" className="mb-4 p-3 bg-gray-50 rounded border hidden">
              <p id="description-text" className="text-sm text-gray-700"></p>
            </div>

            <div id="parameters-section" className="hidden">
              <h3 className="font-medium text-gray-700 mb-3">Algorithm Parameters:</h3>
              <div id="parameters-container"></div>
            </div>

            <button id="process-btn" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed mt-4" disabled>
              <i className="fas fa-magic mr-2"></i>
              Process Image
            </button>
          </div>
        </div>

        {/* Results Section */}
        <div id="results-section" className="mt-8 bg-white rounded-lg shadow-lg p-6 hidden">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            <i className="fas fa-image mr-2 text-blue-600"></i>
            Processing Results
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-700 mb-2">Before (Original):</h3>
              <img id="before-image" className="w-full h-64 object-cover rounded border" alt="Before" />
            </div>
            <div>
              <h3 className="font-medium text-gray-700 mb-2">After (Dehazed):</h3>
              <img id="after-image" className="w-full h-64 object-cover rounded border" alt="After" />
            </div>
          </div>

          <div className="mt-4 p-3 bg-gray-50 rounded">
            <div className="flex justify-between text-sm text-gray-600">
              <span>Algorithm: <span id="used-algorithm" className="font-medium"></span></span>
              <span>Processing Time: <span id="processing-time" className="font-medium"></span>ms</span>
            </div>
          </div>

          <div className="mt-4 flex gap-3">
            <button id="download-btn" className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded transition-colors">
              <i className="fas fa-download mr-2"></i>
              Download Result
            </button>
            <button id="reset-btn" className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded transition-colors">
              <i className="fas fa-redo mr-2"></i>
              Process Another
            </button>
          </div>
        </div>

        {/* Information Section */}
        <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            <i className="fas fa-info-circle mr-2 text-blue-600"></i>
            About Multispectral Dehazing
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-eye text-2xl text-blue-600"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Dark Channel Prior</h3>
              <p className="text-sm text-gray-600">
                Exploits the statistical property that most outdoor patches contain pixels with low intensity in at least one color channel.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-cloud text-2xl text-purple-600"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Atmospheric Scattering</h3>
              <p className="text-sm text-gray-600">
                Models the physical process of light scattering through atmospheric particles to reverse haze effects.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-spectrum text-2xl text-green-600"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Multispectral Enhancement</h3>
              <p className="text-sm text-gray-600">
                Leverages information from multiple spectral bands including NIR for enhanced haze detection and removal.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
})

// Helper function to get algorithm details
function getAlgorithmDetails(algorithm: string) {
  const details = {
    'dark-channel-prior': 'Uses statistical properties of haze-free patches',
    'atmospheric-scattering': 'Models physical light scattering through particles',
    'multispectral-enhancement': 'Leverages multiple spectral bands for enhanced processing'
  }
  return details[algorithm] || 'Unknown algorithm'
}

export default app
