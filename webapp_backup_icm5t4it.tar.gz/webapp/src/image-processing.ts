// Image Processing Algorithms for Satellite Dehazing
// Note: These are simplified versions for demonstration in Cloudflare Workers environment

interface ImageData {
  data: Uint8ClampedArray;
  width: number;
  height: number;
}

interface DehazingParameters {
  omega?: number;
  t0?: number;
  radius?: number;
  beta?: number;
  airlight?: number;
  bands?: string[];
  weight_nir?: number;
}

export class SatelliteImageProcessor {
  
  /**
   * Convert base64 image to ImageData for processing
   */
  static async base64ToImageData(base64String: string): Promise<ImageData> {
    // Remove data URL prefix if present
    const base64Data = base64String.replace(/^data:image\/[a-z]+;base64,/, '');
    
    // Decode base64 to binary
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // For demonstration, create a simple ImageData structure
    // In a real implementation, you'd decode the actual image format
    const width = 512; // Default dimensions for demo
    const height = 512;
    const imageData = new Uint8ClampedArray(width * height * 4);
    
    // Generate sample data based on the input for demonstration
    for (let i = 0; i < imageData.length; i += 4) {
      const hash = this.simpleHash(bytes[i % bytes.length] + i);
      imageData[i] = (hash % 200) + 55;     // R
      imageData[i + 1] = (hash % 180) + 75; // G  
      imageData[i + 2] = (hash % 160) + 95; // B
      imageData[i + 3] = 255;               // A
    }
    
    return { data: imageData, width, height };
  }
  
  /**
   * Convert ImageData back to base64 string
   */
  static imageDataToBase64(imageData: ImageData): string {
    // Create a simple PNG-like header for demonstration
    const canvas = this.createVirtualCanvas(imageData.width, imageData.height);
    const ctx = this.getVirtualContext(canvas);
    
    // Put image data onto virtual canvas
    const imgData = ctx.createImageData(imageData.width, imageData.height);
    imgData.data.set(imageData.data);
    ctx.putImageData(imgData, 0, 0);
    
    return canvas.toDataURL('image/png');
  }
  
  /**
   * Dark Channel Prior Dehazing Algorithm
   */
  static darkChannelPrior(imageData: ImageData, params: DehazingParameters): ImageData {
    const { omega = 0.95, t0 = 0.1, radius = 7 } = params;
    const { data, width, height } = imageData;
    const processedData = new Uint8ClampedArray(data);
    
    // Calculate dark channel
    const darkChannel = this.calculateDarkChannel(data, width, height, radius);
    
    // Estimate atmospheric light
    const atmosphericLight = this.estimateAtmosphericLight(data, darkChannel, width, height);
    
    // Calculate transmission map
    const transmission = this.calculateTransmission(data, darkChannel, atmosphericLight, omega, width, height);
    
    // Refine transmission map (simplified)
    const refinedTransmission = this.refineTransmission(transmission, width, height);
    
    // Recover scene radiance
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const t = Math.max(refinedTransmission[y * width + x], t0);
        
        // Dehaze formula: J(x) = (I(x) - A) / max(t(x), t0) + A
        processedData[idx] = Math.min(255, Math.max(0, 
          (data[idx] - atmosphericLight[0]) / t + atmosphericLight[0]
        ));
        processedData[idx + 1] = Math.min(255, Math.max(0,
          (data[idx + 1] - atmosphericLight[1]) / t + atmosphericLight[1]
        ));
        processedData[idx + 2] = Math.min(255, Math.max(0,
          (data[idx + 2] - atmosphericLight[2]) / t + atmosphericLight[2]
        ));
      }
    }
    
    return { data: processedData, width, height };
  }
  
  /**
   * Atmospheric Scattering Model
   */
  static atmosphericScattering(imageData: ImageData, params: DehazingParameters): ImageData {
    const { beta = 1.0, airlight = 0.8 } = params;
    const { data, width, height } = imageData;
    const processedData = new Uint8ClampedArray(data);
    
    for (let i = 0; i < data.length; i += 4) {
      // Simplified atmospheric scattering model
      // I = J * t + A * (1 - t)
      // Where t = e^(-β*d)
      
      const distance = Math.random() * 0.5 + 0.3; // Simulated depth
      const transmission = Math.exp(-beta * distance);
      const A = airlight * 255;
      
      // Recover original radiance
      processedData[i] = Math.min(255, Math.max(0,
        (data[i] - A * (1 - transmission)) / transmission
      ));
      processedData[i + 1] = Math.min(255, Math.max(0,
        (data[i + 1] - A * (1 - transmission)) / transmission
      ));
      processedData[i + 2] = Math.min(255, Math.max(0,
        (data[i + 2] - A * (1 - transmission)) / transmission
      ));
    }
    
    return { data: processedData, width, height };
  }
  
  /**
   * Multispectral Enhancement
   */
  static multispectralEnhancement(imageData: ImageData, params: DehazingParameters): ImageData {
    const { bands = ['red', 'green', 'blue', 'nir'], weight_nir = 1.2 } = params;
    const { data, width, height } = imageData;
    const processedData = new Uint8ClampedArray(data);
    
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      
      // Simulate NIR band from visible bands
      const nir = Math.min(255, (r + g) / 2 * weight_nir);
      
      // Enhanced vegetation index for better haze detection
      const ndvi = (nir - r) / (nir + r + 0.001);
      const hazeFactor = Math.max(0, 1 - Math.abs(ndvi) * 2);
      
      // Apply haze reduction based on spectral analysis
      processedData[i] = Math.min(255, r + (255 - r) * hazeFactor * 0.3);
      processedData[i + 1] = Math.min(255, g + (255 - g) * hazeFactor * 0.25);
      processedData[i + 2] = Math.min(255, b + (255 - b) * hazeFactor * 0.2);
    }
    
    return { data: processedData, width, height };
  }
  
  // Helper methods for image processing
  private static calculateDarkChannel(data: Uint8ClampedArray, width: number, height: number, radius: number): number[] {
    const darkChannel = new Array(width * height).fill(255);
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        let minVal = 255;
        
        // Find minimum in local patch
        for (let dy = -radius; dy <= radius; dy++) {
          for (let dx = -radius; dx <= radius; dx++) {
            const ny = Math.max(0, Math.min(height - 1, y + dy));
            const nx = Math.max(0, Math.min(width - 1, x + dx));
            const idx = (ny * width + nx) * 4;
            
            const localMin = Math.min(data[idx], data[idx + 1], data[idx + 2]);
            minVal = Math.min(minVal, localMin);
          }
        }
        
        darkChannel[y * width + x] = minVal;
      }
    }
    
    return darkChannel;
  }
  
  private static estimateAtmosphericLight(data: Uint8ClampedArray, darkChannel: number[], width: number, height: number): number[] {
    // Find brightest pixels in dark channel
    let maxDark = 0;
    let maxIdx = 0;
    
    for (let i = 0; i < darkChannel.length; i++) {
      if (darkChannel[i] > maxDark) {
        maxDark = darkChannel[i];
        maxIdx = i;
      }
    }
    
    const idx = maxIdx * 4;
    return [data[idx], data[idx + 1], data[idx + 2]];
  }
  
  private static calculateTransmission(data: Uint8ClampedArray, darkChannel: number[], atmosphericLight: number[], omega: number, width: number, height: number): number[] {
    const transmission = new Array(width * height);
    
    for (let i = 0; i < transmission.length; i++) {
      const maxA = Math.max(atmosphericLight[0], atmosphericLight[1], atmosphericLight[2]);
      transmission[i] = 1 - omega * (darkChannel[i] / maxA);
    }
    
    return transmission;
  }
  
  private static refineTransmission(transmission: number[], width: number, height: number): number[] {
    // Simple box filter for refinement
    const refined = new Array(width * height);
    const radius = 3;
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        let sum = 0;
        let count = 0;
        
        for (let dy = -radius; dy <= radius; dy++) {
          for (let dx = -radius; dx <= radius; dx++) {
            const ny = y + dy;
            const nx = x + dx;
            
            if (ny >= 0 && ny < height && nx >= 0 && nx < width) {
              sum += transmission[ny * width + nx];
              count++;
            }
          }
        }
        
        refined[y * width + x] = sum / count;
      }
    }
    
    return refined;
  }
  
  // Virtual canvas methods for Cloudflare Workers environment
  private static createVirtualCanvas(width: number, height: number) {
    return {
      width,
      height,
      toDataURL: (format: string) => {
        // Return a placeholder data URL for demo
        return `data:image/png;base64,${btoa('processed-image-placeholder')}`;
      }
    };
  }
  
  private static getVirtualContext(canvas: any) {
    return {
      createImageData: (width: number, height: number) => ({
        data: new Uint8ClampedArray(width * height * 4),
        width,
        height
      }),
      putImageData: (imageData: any, x: number, y: number) => {
        // Placeholder implementation
      }
    };
  }
  
  private static simpleHash(num: number): number {
    let hash = 0;
    const str = num.toString();
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }
}