import { jsxRenderer } from 'hono/jsx-renderer'

export const renderer = jsxRenderer(({ children }) => {
  return (
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Multispectral Satellite Image Dehazing</title>
        
        {/* TailwindCSS for styling */}
        <script src="https://cdn.tailwindcss.com"></script>
        
        {/* FontAwesome for icons */}
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet" />
        
        {/* Custom styles */}
        <link href="/static/style.css" rel="stylesheet" />
        
        {/* Configure TailwindCSS */}
        <script>
          {`tailwind.config = {
            theme: {
              extend: {
                colors: {
                  primary: '#3B82F6',
                  secondary: '#8B5CF6'
                }
              }
            }
          }`}
        </script>
      </head>
      <body className="bg-gray-50">
        {children}
        
        {/* JavaScript libraries */}
        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        
        {/* Application JavaScript */}
        <script src="/static/app.js"></script>
      </body>
    </html>
  )
})
