// Multispectral Satellite Image Dehazing Application
class SatelliteDehazing {
  constructor() {
    this.currentImageData = null;
    this.algorithms = [];
    this.init();
  }

  async init() {
    await this.loadAlgorithms();
    this.setupEventListeners();
  }

  async loadAlgorithms() {
    try {
      const response = await axios.get('/api/algorithms');
      this.algorithms = response.data.algorithms;
      this.populateAlgorithmSelect();
    } catch (error) {
      console.error('Failed to load algorithms:', error);
      this.showMessage('Failed to load algorithms', 'error');
    }
  }

  populateAlgorithmSelect() {
    const select = document.getElementById('algorithm-select');
    select.innerHTML = '<option value="">Choose an algorithm...</option>';
    
    this.algorithms.forEach(algorithm => {
      const option = document.createElement('option');
      option.value = algorithm.id;
      option.textContent = algorithm.name;
      select.appendChild(option);
    });
  }

  setupEventListeners() {
    // File input handling
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('image-input');

    uploadArea.addEventListener('click', () => fileInput.click());
    uploadArea.addEventListener('dragover', this.handleDragOver.bind(this));
    uploadArea.addEventListener('drop', this.handleDrop.bind(this));
    fileInput.addEventListener('change', this.handleFileSelect.bind(this));

    // Algorithm selection
    document.getElementById('algorithm-select').addEventListener('change', this.handleAlgorithmChange.bind(this));

    // Process button
    document.getElementById('process-btn').addEventListener('click', this.processImage.bind(this));

    // Download and reset buttons
    document.getElementById('download-btn')?.addEventListener('click', this.downloadResult.bind(this));
    document.getElementById('reset-btn')?.addEventListener('click', this.resetInterface.bind(this));
  }

  handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.add('border-blue-400', 'bg-blue-50');
  }

  handleDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.remove('border-blue-400', 'bg-blue-50');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      this.handleFile(files[0]);
    }
  }

  handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
      this.handleFile(file);
    }
  }

  async handleFile(file) {
    if (!file.type.startsWith('image/')) {
      this.showMessage('Please select a valid image file', 'error');
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      this.showMessage('File size must be less than 10MB', 'error');
      return;
    }

    this.showMessage('Uploading image...', 'info');

    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await axios.post('/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data.success) {
        this.currentImageData = response.data.data;
        this.displayOriginalImage(response.data);
        this.showMessage('Image uploaded successfully!', 'success');
      } else {
        throw new Error(response.data.error);
      }
    } catch (error) {
      console.error('Upload error:', error);
      this.showMessage('Failed to upload image', 'error');
    }
  }

  displayOriginalImage(imageInfo) {
    const preview = document.getElementById('image-preview');
    const image = document.getElementById('original-image');
    const info = document.getElementById('image-info');

    image.src = imageInfo.data;
    info.textContent = `${imageInfo.filename} (${this.formatFileSize(imageInfo.size)})`;
    preview.classList.remove('hidden');

    this.updateProcessButton();
  }

  handleAlgorithmChange(e) {
    const algorithmId = e.target.value;
    const algorithm = this.algorithms.find(a => a.id === algorithmId);

    if (algorithm) {
      this.displayAlgorithmInfo(algorithm);
      this.createParameterInputs(algorithm);
    } else {
      this.hideAlgorithmInfo();
    }

    this.updateProcessButton();
  }

  displayAlgorithmInfo(algorithm) {
    const description = document.getElementById('algorithm-description');
    const text = document.getElementById('description-text');

    text.textContent = algorithm.description;
    description.classList.remove('hidden');
  }

  hideAlgorithmInfo() {
    document.getElementById('algorithm-description').classList.add('hidden');
    document.getElementById('parameters-section').classList.add('hidden');
  }

  createParameterInputs(algorithm) {
    const section = document.getElementById('parameters-section');
    const container = document.getElementById('parameters-container');

    container.innerHTML = '';

    algorithm.parameters.forEach(param => {
      const div = document.createElement('div');
      div.className = 'mb-3';

      if (param.type === 'number') {
        div.innerHTML = `
          <label class="block text-sm font-medium text-gray-700 mb-1">${param.description}</label>
          <input 
            type="number" 
            id="param-${param.name}" 
            value="${param.default}" 
            min="${param.min}" 
            max="${param.max}" 
            step="0.01"
            class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
          <div class="text-xs text-gray-500 mt-1">Range: ${param.min} - ${param.max}</div>
        `;
      } else if (param.type === 'array') {
        const options = param.default.map(item => 
          `<option value="${item}" selected>${item.toUpperCase()}</option>`
        ).join('');
        
        div.innerHTML = `
          <label class="block text-sm font-medium text-gray-700 mb-1">${param.description}</label>
          <select multiple id="param-${param.name}" class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            ${options}
          </select>
        `;
      }

      container.appendChild(div);
    });

    section.classList.remove('hidden');
  }

  async processImage() {
    if (!this.currentImageData) {
      this.showMessage('Please upload an image first', 'error');
      return;
    }

    const algorithmSelect = document.getElementById('algorithm-select');
    const selectedAlgorithm = algorithmSelect.value;

    if (!selectedAlgorithm) {
      this.showMessage('Please select an algorithm', 'error');
      return;
    }

    const algorithm = this.algorithms.find(a => a.id === selectedAlgorithm);
    const parameters = this.collectParameters(algorithm);

    this.showMessage('Processing image...', 'info');
    document.getElementById('process-btn').disabled = true;

    try {
      const response = await axios.post('/api/dehaze', {
        imageData: this.currentImageData,
        algorithm: selectedAlgorithm,
        parameters: parameters
      });

      if (response.data.success) {
        this.displayResults(response.data);
        this.showMessage('Image processed successfully!', 'success');
      } else {
        throw new Error(response.data.error);
      }
    } catch (error) {
      console.error('Processing error:', error);
      this.showMessage('Failed to process image', 'error');
    } finally {
      document.getElementById('process-btn').disabled = false;
    }
  }

  collectParameters(algorithm) {
    const parameters = {};
    
    algorithm.parameters.forEach(param => {
      const element = document.getElementById(`param-${param.name}`);
      if (element) {
        if (param.type === 'number') {
          parameters[param.name] = parseFloat(element.value);
        } else if (param.type === 'array') {
          parameters[param.name] = Array.from(element.selectedOptions).map(opt => opt.value);
        }
      }
    });

    return parameters;
  }

  displayResults(result) {
    const resultsSection = document.getElementById('results-section');
    const beforeImage = document.getElementById('before-image');
    const afterImage = document.getElementById('after-image');
    const usedAlgorithm = document.getElementById('used-algorithm');
    const processingTime = document.getElementById('processing-time');

    beforeImage.src = this.currentImageData;
    afterImage.src = result.processedImage;
    usedAlgorithm.textContent = this.algorithms.find(a => a.id === result.algorithm)?.name || result.algorithm;
    processingTime.textContent = Math.round(result.processingTime);

    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth' });

    // Store processed result for download
    this.processedImageData = result.processedImage;
  }

  downloadResult() {
    if (!this.processedImageData) {
      this.showMessage('No processed image to download', 'error');
      return;
    }

    const link = document.createElement('a');
    link.href = this.processedImageData;
    link.download = 'dehazed-satellite-image.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    this.showMessage('Image downloaded!', 'success');
  }

  resetInterface() {
    // Reset form
    document.getElementById('image-input').value = '';
    document.getElementById('algorithm-select').value = '';
    
    // Hide sections
    document.getElementById('image-preview').classList.add('hidden');
    document.getElementById('results-section').classList.add('hidden');
    this.hideAlgorithmInfo();

    // Clear data
    this.currentImageData = null;
    this.processedImageData = null;

    // Update button state
    this.updateProcessButton();

    this.showMessage('Interface reset', 'info');
  }

  updateProcessButton() {
    const btn = document.getElementById('process-btn');
    const hasImage = !!this.currentImageData;
    const hasAlgorithm = !!document.getElementById('algorithm-select').value;
    
    btn.disabled = !(hasImage && hasAlgorithm);
  }

  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  showMessage(message, type = 'info') {
    // Remove existing messages
    const existingMessages = document.querySelectorAll('.alert-message');
    existingMessages.forEach(msg => msg.remove());

    const alertDiv = document.createElement('div');
    alertDiv.className = `alert-message fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 max-w-sm ${this.getAlertClasses(type)}`;
    
    alertDiv.innerHTML = `
      <div class="flex items-center">
        <i class="fas ${this.getAlertIcon(type)} mr-2"></i>
        <span>${message}</span>
      </div>
    `;

    document.body.appendChild(alertDiv);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (alertDiv.parentNode) {
        alertDiv.remove();
      }
    }, 5000);
  }

  getAlertClasses(type) {
    const classes = {
      'success': 'bg-green-100 border border-green-400 text-green-700',
      'error': 'bg-red-100 border border-red-400 text-red-700',
      'info': 'bg-blue-100 border border-blue-400 text-blue-700',
      'warning': 'bg-yellow-100 border border-yellow-400 text-yellow-700'
    };
    return classes[type] || classes['info'];
  }

  getAlertIcon(type) {
    const icons = {
      'success': 'fa-check-circle',
      'error': 'fa-exclamation-circle',
      'info': 'fa-info-circle',
      'warning': 'fa-exclamation-triangle'
    };
    return icons[type] || icons['info'];
  }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new SatelliteDehazing();
});